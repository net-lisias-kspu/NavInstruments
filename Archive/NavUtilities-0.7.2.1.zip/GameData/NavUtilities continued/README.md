NavUtilities Unofficial
=================================

This is a continuation of NavInstruments mod by kujuman. This is an **unofficial** fork by Lisias.


In a Hurry
----------
Propeller plane and helicopter part modules for Kerbal Space Program.

* [Latest Release](https://github.com/net-lisias-kspu/Firespitter/releases)
* [Source](https://github.com/net-lisias-kspu/Firespitter)
* [Binaries](https://github.com/net-lisias-kspu/NavInstruments/tree/Archive)
* [Change Log](./CHANGE_LOG.md)

Description
-----------
This mod for KSP is intended to provide navigation instruments in both IVA and external views


UPSTREAM
--------
* [Forum](https://forum.kerbalspaceprogram.com/index.php?/topic/162967-14x-navutilities-continued-ft-hsi-instrument-landing-system-v072-2018-apr-1/)
* [SpaceDock](https://spacedock.info/mod/1432/NavUtilities%20continued)
* [GitHub](https://github.com/SerTheGreat/NavInstruments)
	* [Parent Fork](https://github.com/kujuman/NavInstruments)
